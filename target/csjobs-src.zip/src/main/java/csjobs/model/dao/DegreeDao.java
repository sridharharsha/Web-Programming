package csjobs.model.dao;

import csjobs.model.Degree;

public interface DegreeDao {
	
	Degree saveDegree(Degree degree);

}

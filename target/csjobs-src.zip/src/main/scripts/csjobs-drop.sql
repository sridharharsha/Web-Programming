drop table application_degrees;
drop table job_committee_members;
drop table reviews;
drop table rounds;
drop table applications;
drop table files;
drop table jobs;
drop table authorities;
drop table users;

drop sequence hibernate_sequence;